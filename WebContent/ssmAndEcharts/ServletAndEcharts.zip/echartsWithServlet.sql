/*
Navicat MySQL Data Transfer

Source Server         : 133
Source Server Version : 50713
Source Host           : 192.168.1.181:3306
Source Database       : echarts

Target Server Type    : MYSQL
Target Server Version : 50713
File Encoding         : 65001

Date: 2017-03-17 17:59:40
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for bar
-- ----------------------------
DROP TABLE IF EXISTS `bar`;
CREATE TABLE `bar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(11) DEFAULT NULL,
  `num` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of bar
-- ----------------------------
INSERT INTO `bar` VALUES ('1', '寸衫', '5');
INSERT INTO `bar` VALUES ('2', '羊毛衫', '10');
INSERT INTO `bar` VALUES ('3', '裤子', '21');
INSERT INTO `bar` VALUES ('4', '鞋', '32');
INSERT INTO `bar` VALUES ('5', '帽子', '5');

-- ----------------------------
-- Table structure for evaporation
-- ----------------------------
DROP TABLE IF EXISTS `evaporation`;
CREATE TABLE `evaporation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `num` int(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of evaporation
-- ----------------------------
INSERT INTO `evaporation` VALUES ('1', '32');
INSERT INTO `evaporation` VALUES ('2', '34');
INSERT INTO `evaporation` VALUES ('3', '543');
INSERT INTO `evaporation` VALUES ('4', '34');
INSERT INTO `evaporation` VALUES ('5', '54');
INSERT INTO `evaporation` VALUES ('6', '65');
INSERT INTO `evaporation` VALUES ('7', '65');
INSERT INTO `evaporation` VALUES ('8', '765');
INSERT INTO `evaporation` VALUES ('9', '67');
INSERT INTO `evaporation` VALUES ('10', '765');
INSERT INTO `evaporation` VALUES ('11', '57');
INSERT INTO `evaporation` VALUES ('12', '34');

-- ----------------------------
-- Table structure for rainfall
-- ----------------------------
DROP TABLE IF EXISTS `rainfall`;
CREATE TABLE `rainfall` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `num` int(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of rainfall
-- ----------------------------
INSERT INTO `rainfall` VALUES ('1', '121');
INSERT INTO `rainfall` VALUES ('2', '232');
INSERT INTO `rainfall` VALUES ('3', '231');
INSERT INTO `rainfall` VALUES ('4', '431');
INSERT INTO `rainfall` VALUES ('5', '121');
INSERT INTO `rainfall` VALUES ('6', '121');
INSERT INTO `rainfall` VALUES ('7', '211');
INSERT INTO `rainfall` VALUES ('8', '122');
INSERT INTO `rainfall` VALUES ('9', '233');
INSERT INTO `rainfall` VALUES ('10', '234');
INSERT INTO `rainfall` VALUES ('11', '231');
INSERT INTO `rainfall` VALUES ('12', '234');
