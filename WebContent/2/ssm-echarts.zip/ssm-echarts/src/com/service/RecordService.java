package com.service;

import com.po.Record;

import java.util.List;

public interface RecordService {
    List<Record>  selecMore();
}