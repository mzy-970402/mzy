package com.mapper;

import com.po.Record;

import java.util.List;


public interface RecordMapper {
      List<Record> selecMore();
}
