package com.util;

/**
 * Created by Administrator on 2016/12/5.
 */
public class StringUtils {
    public static boolean isEmpty(String str){
        return str==null||str.equals("");
    }
}